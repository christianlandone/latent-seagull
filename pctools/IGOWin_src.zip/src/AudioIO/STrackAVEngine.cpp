#include "STrackAVEngine.h"
#include "..\IGOControllerMain.h"

#include <wx/file.h>
#include "sndfile.h"

class AVPlaybackThread : public wxThread {
 public:
   AVPlaybackThread():wxThread(wxTHREAD_JOINABLE) {}
   virtual ExitCode Entry();
};

class AVRealTimeThread : public wxThread {
 public:
	 AVRealTimeThread():wxThread(wxTHREAD_JOINABLE) {}
   virtual ExitCode Entry();
};


STrackAVEngine* gAVEngine;

void InitAVEngine()
{
	gAVEngine = new STrackAVEngine;
}

void DeinitAVEngine()
{
	delete gAVEngine;
}

STrackAVEngine::STrackAVEngine()
:mAudioData(NULL)
,mParent(NULL)
,mOutputBuffer(0)
,m_frameSize(1920)
,bPAIsOpen(false)
,bIsPaused(false)
,bIsStopped(true)
,mPBStartFrame(0)
,mPBEndFrame(0)
,mPBFrameCounter(0)
,mIsSafe(true)
,mMasterSampleRate(16000)
,mCurrentAudioFrame(0)
,mTracksUpdated(false)
,mPacketsBuffer(NULL)
,mPacketSize(0)
,mPacketBufferSize(0)
,mPacketsAligned(false)
,mResetPacketsBuffer(false)
{
	mOutputBuffer = new float[m_frameSize*MAX_AUDIO_TRACKS];

	mPacketSize = SERIAL_PACKET_LENGTH;
	mPacketBufferSize = mPacketSize * 100;

	mPacketsBuffer = new RingBuffer(mPacketBufferSize);
	mResetPacketsBuffer = true;
}

STrackAVEngine::~STrackAVEngine()
{
    unloadAsset();

	DeinitialiseAudioOut();

    if( mOutputBuffer )
    {
        delete [] mOutputBuffer;
        mOutputBuffer = 0;
    }

	if (mPacketsBuffer)
	{
		delete mPacketsBuffer;
		mPacketsBuffer = NULL;
	}
}

void
STrackAVEngine::SetParent(IGOControllerFrame* parent)
{
	mParent = parent;
}

/////////////////////////////////////////////////////////////////
bool STrackAVEngine::InitialiseAudioOut( size_t sampleRate, size_t channels, size_t frameSize )
{
    // Portaudio stream
	mPAStream = NULL;
    err = Pa_Initialize();
    if( err == paNoError )
    {
        mPAOutputParameters.device = Pa_GetDefaultOutputDevice(); /* default output device */
        mPAOutputParameters.channelCount = channels;
        mPAOutputParameters.sampleFormat = paFloat32;
        mPAOutputParameters.suggestedLatency = Pa_GetDeviceInfo( mPAOutputParameters.device )->defaultHighOutputLatency;
        mPAOutputParameters.hostApiSpecificStreamInfo = NULL;

        err = Pa_OpenStream( &mPAStream,
                             NULL,
                             &mPAOutputParameters,
                             sampleRate,
                             frameSize,
                             paClipOff,      /* we won't output out of range samples so don't bother clipping them */
                             NULL, /* no callback, use blocking API */
                             NULL ); /* no callback, so no callback userData */

        if( err == paNoError )
        {
            /* -- start stream -- */
            err = Pa_StartStream( mPAStream );

            if( err == paNoError )
            {
                bPAIsOpen = TRUE;
            }
        }
    }
    return true;
}

bool STrackAVEngine::DeinitialiseAudioOut()
{
    if( bPAIsOpen )
	{
        err = Pa_CloseStream( mPAStream );
        if( err == paNoError )
        {
            Pa_Terminate();
            bPAIsOpen = FALSE;
        }
	}
	return true;
}

bool STrackAVEngine::loadAsset( std::string path )
{
    mTracksUpdated = false;
    unloadAsset();

	mAudioData = sf_open((const char*)path.c_str(), SFM_READ, &mAudioDataInfo);

    if(mAudioData)
    {
        mMasterSampleRate = mAudioDataInfo.samplerate;
        InitialiseAudioOut(mAudioDataInfo.samplerate, mAudioDataInfo.channels, m_frameSize );
        mTracksUpdated = true;
        return true;
    }
    else
    {
        mMasterSampleRate = 0;
        mTracksUpdated = true;
        return false;
    }
}

bool STrackAVEngine::unloadAsset()
{
    mTracksUpdated = false;

	if( mAudioData )
	{
		sf_close(mAudioData);
		mAudioData = NULL;
	}

    mTracksUpdated = true;
    return true;
}

bool STrackAVEngine::SetPBRange( size_t startFrame, size_t endFrame )
{
	if( mAudioData && mMasterSampleRate )
    {
        mPBStartFrame = startFrame;
        mPBFrameCounter = startFrame;

        if( endFrame == startFrame )
        {
			mPBEndFrame = mAudioDataInfo.frames;
        }
        else
            mPBEndFrame   = endFrame;

        sf_seek( mAudioData, mPBStartFrame, SEEK_SET);

        return true;
    }
    return false;
}

void STrackAVEngine::setPBSecs( float startSecs, float endSecs)
{
    size_t startFrame = (size_t)(startSecs*(float)mMasterSampleRate);
    size_t endFrame = (size_t)(endSecs*(float)mMasterSampleRate);
    setPBFrame(startFrame, endFrame);
}

void STrackAVEngine::setPBFrame( size_t startFrame, size_t endFrame )
{
    PauseAVEngine();
    SetPBRange( startFrame, endFrame );
    ResumeAVEngine();
}

bool STrackAVEngine::StartPlayBack( size_t startFrame, size_t endFrame )
{
    bool pbStarted = false;

    if( mMasterSampleRate == 0 )
        return false;

	if( SetPBRange( startFrame, endFrame) )
    {
        mCurrentAudioFrame = 0;
        bIsPaused = false;
        mPlayBackStatus = PBPlay;
        if( bIsStopped )
        {
            bIsStopped = false;
            mPlaybackThread = new AVPlaybackThread;
            mPlaybackThread->Create();
			mPlaybackThread->SetPriority(wxPRIORITY_MAX);
            mPlaybackThread->Run();
        }
        pbStarted = true;
    }
    return pbStarted;
}

void STrackAVEngine::StopPlayBack()
{
    bIsPaused = false;

	bIsStopped = true;

	while( mIsSafe == false )
    {
        wxMilliSleep(1);
    }

	if (mAudioData)
		sf_seek(mAudioData, 0, SEEK_SET);

	mPlayBackStatus = PBStop;
}

void STrackAVEngine::PausePlayBack()
{
	bIsPaused = !bIsPaused;

    if( bIsPaused )
    {
        mPlayBackStatus = PBPause;
    }
    else
    {
        mPlayBackStatus = PBPlay;
    }
}

void STrackAVEngine::PauseAVEngine()
{
    bIsPaused = true;
    while( mIsSafe == false )
    {
        wxMilliSleep(10);
    }
}

void STrackAVEngine::ResumeAVEngine()
{
    bIsPaused = false;
}


void STrackAVEngine::DoPlayback()
{
	while( bIsStopped == false )
	{
		if( bIsPaused == false )
		{
		    mIsSafe = false;

            if( bPAIsOpen )
            {
                /////////////////////////////////////////////////////////////////////////////
				int rd = sf_readf_float(mAudioData, mOutputBuffer, m_frameSize);
                mPBFrameCounter += m_frameSize;
				mCurrentAudioFrame = mPBFrameCounter;
				if ((mPBFrameCounter >= mPBEndFrame))
					bIsStopped = true;

                err = Pa_WriteStream( mPAStream, mOutputBuffer, m_frameSize );				
            }
		}
		else
		{
		    mIsSafe = true;
		    wxMilliSleep( 10 );
		}
	}

	bIsStopped = true;
	mIsSafe = true;
}

LevelAnalyser* STrackAVEngine::getOutputLevelMetrics()
{
	return 0;
}


bool 
STrackAVEngine::IsPBStopped()
{
	return bIsStopped;
}

bool 
STrackAVEngine::IsAssetLoaded()
{
    return mTracksUpdated;
}

void
STrackAVEngine::reportEvent( procid_t processID, 
							 eventtype_t eventType,
							 eventid_t   eventID,
							 float value,
							 wxString message, 
							 bool killProcess, 
							 wxString debugInfo)
{
	if (mParent)
	{
		IGOThreadEvent tevent;
		tevent.processID = processID;
		tevent.eventID = eventID;
		tevent.eventMessage = message;
		tevent.threadFinished = killProcess;
		tevent.debugInfo = debugInfo;
		tevent.eventCounter = value;

		wxThreadEvent event(wxEVT_THREAD, IGORX_EVENT);
		event.SetPayload(tevent);
		wxQueueEvent(mParent, event.Clone());
	}
}


/////////////////////////
//threads entry points
AVPlaybackThread::ExitCode AVPlaybackThread::Entry()
{
	gAVEngine->DoPlayback();
	return 0;
}


///////////////////////////////////////////////////
// Getters
void  STrackAVEngine::GetPlayBackStatus( int* status )
{
    *status = mPlayBackStatus;
}

size_t STrackAVEngine::getMasterTrackCurrentFrame()
{
    return mCurrentAudioFrame;
}

size_t STrackAVEngine::getMasterTrackDataSize()
{
    size_t retVal = mAudioDataInfo.frames;

    return retVal;
}

size_t STrackAVEngine::getMasterTrackSampleRate()
{
    return mMasterSampleRate;
}


/////////////////////////////////////////////////////////
//real time audio
bool 
STrackAVEngine::ingestPackets(unsigned char* data, size_t datasize)
{
	bool status = true;

	if (mResetPacketsBuffer)
	{
		mPacketsBuffer->reset();
		mPacketsBuffer->zero(mPacketBufferSize);
		mResetPacketsBuffer = false;
	}

	int hdrIndex = 0;
	if (!mPacketsAligned)
	{
		for (size_t i = 0; i < datasize; i++)
		{
			if ((data[i] == 'R'))
			{
				mPacketsAligned = true;
				mPacketsBuffer->reset();
				reportEvent(AUDIO_THREAD, CONTROL_EVT, RX_SYNCED_OK, 0, wxT("sync ok"));
				break;
			}
			hdrIndex++;
		}
	}

	if(mPacketsAligned)
		mPacketsBuffer->write(data+ hdrIndex, datasize- hdrIndex);

	return status;
}

bool 
STrackAVEngine::StartRealTime()
{
	bool pbStarted = false;

	mPacketsAligned = false;

	mSyncEvents = 0;
	mAudioBufferEvents = 0;

	writtenDuringSearch = 0;

	if (mMasterSampleRate == 0)
		return false;

	bIsPaused = false;
	mPlayBackStatus = PBPlay;

	InitialiseAudioOut(16000, 1, m_frameSize);
	adpcm64_decode_init(&decoder);

	if (bIsStopped)
	{
		bIsStopped = false;
		mRealTimeThread = new AVRealTimeThread;
		mRealTimeThread->Create();
		mRealTimeThread->Run();
	}

	pbStarted = true;
	return pbStarted;
}

void STrackAVEngine::StopRealTime()
{
	bIsPaused = false;

	bIsStopped = true;

	while (mIsSafe == false)
	{
		wxMilliSleep(10);
	}

	DeinitialiseAudioOut();

	mPlayBackStatus = PBStop;
}


void STrackAVEngine::DoRealTime()
{
	wxString wDebugMsg;
	int searchSize = 9;
	uint8_t* searchBuf = new uint8_t[searchSize];
	uint8_t* packetBuf = new uint8_t[mPacketSize];
	
	bool headerFound = false;
	int headerPos = -1;

	unsigned short*  buffer_in = new unsigned short[1024];
	unsigned short*  buffer_tmp = new unsigned short[1024];
	short*   buffer_out = new short[1024];
	int read = 0;
	int toBuffer = 0;
	SAMPLE* pOut = mOutputBuffer;

	while (bIsStopped == false)
	{
		if (bIsPaused == false)
		{
			mIsSafe = false;

			if (bPAIsOpen)
			{
				/////////////////////////////////////////////////////////////////////////////
				if (mPacketsBuffer && mPacketsAligned)
				{
					int avBufData = mPacketsBuffer->getReadSpace();
					if( (avBufData > mPacketSize * 30))
					{
						mPacketsBuffer->peek(packetBuf, mPacketSize);
						mPacketsBuffer->skip(mPacketSize);

						if ((packetBuf[0] != 'R') && (packetBuf[1] != 'X'))
						{
							mPacketsAligned = false;
							mResetPacketsBuffer = true;
							mSyncEvents++;
							mAudioBufferEvents = 0;
							reportEvent(AUDIO_THREAD, CONTROL_EVT, RX_SYNCED_KO, mSyncEvents, wxT("sync lost"));
						}
						else
						{
							uint8_t* pb = packetBuf+ SERIAL_HEADER_LENGTH + RX_HEADER_LENGTH;
							read = adpcm64_unpack_vadim((unsigned short*)pb, buffer_tmp, G722_DATA_LENGTH/2);
							read = adpcm64_decode_run(&decoder, buffer_tmp, buffer_out, read);

							for (int i = 0; i < read; i++)
							{
								*pOut++ = ((float)buffer_out[i]) / 32767;
								toBuffer++;
							}

							if (toBuffer >= m_frameSize/5)
							{
								err = Pa_WriteStream(mPAStream, mOutputBuffer, toBuffer);
								toBuffer = 0;
								pOut = mOutputBuffer;
							}
						}		
					}
					else
					{						
						wxMilliSleep(50);

						if ((avBufData <= 5 * mPacketSize))
						{
							mAudioBufferEvents++;
							wDebugMsg = (_T("audio buffering"));
							reportEvent(AUDIO_THREAD, CONTROL_EVT, AUDIO_BUF_UNDER, mAudioBufferEvents, wDebugMsg);
						}
					}
				}
			}
		}
		else
		{
			mIsSafe = true;
			wxMilliSleep(10);
		}
	}

	delete[] searchBuf;
	delete[] packetBuf;

	delete[] buffer_in;
	delete[] buffer_tmp;
	delete[] buffer_out;

	bIsStopped = true;
	mIsSafe = true;
}

/////////////////////////
//threads entry points
AVRealTimeThread::ExitCode AVRealTimeThread::Entry()
{
	gAVEngine->DoRealTime();
	return 0;
}
