#include <wx/wx.h>
#include <wx/xml/xml.h>
#include <wx/string.h>

#include "portaudio.h"
#include "pa_ringbuffer.h"
#include "pa_util.h"
#include "LevelAnalyser.h"
#include "RingBuffer.h"
#include "sndfile.h"
#include "..\g722\adpcm64_coder.h"
#include "..\g722\adpcm64_decoder.h"
#include "../IGODefs.h"

typedef float SAMPLE;

class AVPlaybackThread;
class AVRealTimeThread;
class IGOControllerFrame;


class STrackAVEngine;

extern STrackAVEngine* gAVEngine;

void InitAVEngine();
void DeinitAVEngine();

#define MAX_AUDIO_TRACKS 8


class STrackAVEngine
{
public:
    STrackAVEngine();
	~STrackAVEngine();

	void SetParent(IGOControllerFrame* parent);

    void GetPlayBackStatus( int* status );

	bool ingestPackets(unsigned char* data, size_t datasize);

    bool loadAsset( std::string path );
    bool unloadAsset();

    bool InitialiseAudioOut( size_t sampleRate, size_t channels, size_t frameSize );
    bool DeinitialiseAudioOut();

    size_t getMasterTrackCurrentFrame();
    size_t getMasterTrackDataSize();
    size_t getMasterTrackSampleRate();

	//real time audio
	bool StartRealTime();
	void StopRealTime();
	void DoRealTime();

    //Playback transport
	bool StartPlayBack( size_t startFrame, size_t endFrame);
	void setPBFrame( size_t startFrame, size_t endFrame);
	void setPBSecs( float startSecs, float endSecs);

	void StopPlayBack();
	void PausePlayBack();

    /////////////////////////////////////////////////////
	void DoPlayback();
	void PauseAVEngine();
	void ResumeAVEngine();

	bool IsPBStopped();
	bool IsAssetLoaded();

    enum PBState
    {  PBStop = 0,
       PBPlay,
       PBPause};

    LevelAnalyser*    getOutputLevelMetrics();

protected:
	void reportEvent( procid_t processID,
					  eventtype_t eventType,
					  eventid_t   eventID,
					  float value,
		              wxString message,
		              bool killProcess = false,
		              wxString debugInfo = wxEmptyString);

    bool SetPBRange( size_t startFrame, size_t endFrame );

protected:
	IGOControllerFrame* mParent;

	size_t mPBStartFrame;
	size_t mPBEndFrame;
	size_t mPBFrameCounter;

	AVPlaybackThread* mPlaybackThread;
	AVRealTimeThread* mRealTimeThread;

    PaError err;
    PaStreamParameters mPAOutputParameters;
    PaStream *mPAStream;
	bool bPAIsOpen;

	size_t mMasterSampleRate;
    size_t mCurrentAudioFrame;

	SAMPLE* mOutputBuffer;

	bool bIsPaused;
    bool bIsStopped;
    int  mPlayBackStatus;

	size_t m_frameSize;

    volatile bool mIsSafe;   
    volatile bool mTracksUpdated;

	SNDFILE* mAudioData;
	SF_INFO  mAudioDataInfo;


	G722DECODER decoder;

	RingBuffer* mPacketsBuffer;
	size_t mPacketSize;
	size_t mPacketBufferSize;
	volatile size_t writtenDuringSearch;
	volatile bool mPacketsAligned;
	volatile bool mResetPacketsBuffer;

	size_t mSyncEvents;
	size_t mAudioBufferEvents;
};
