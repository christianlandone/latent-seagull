/***************************************************************
 * Name:      IGOControllerApp.h
 * Purpose:   Defines Application Class
 * Author:    clandone ()
 * Created:   2017-09-20
 * Copyright: clandone ()
 * License:
 **************************************************************/

#ifndef IGOCONTROLLERAPP_H
#define IGOCONTROLLERAPP_H

#include <wx/app.h>

class IGOControllerApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // IGOCONTROLLERAPP_H
