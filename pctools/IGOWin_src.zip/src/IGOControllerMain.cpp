/***************************************************************
 * Name:      IGOControllerMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    clandone ()
 * Created:   2017-09-20
 * Copyright: clandone ()
 * License:
 **************************************************************/

#include "IGOControllerMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(IGOControllerFrame)
#include <wx/bitmap.h>
#include <wx/icon.h>
#include <wx/font.h>
#include <wx/intl.h>
#include <wx/image.h>
#include <wx/string.h>
//*)

#include "comms\CommsEngine.h"
#include "g722\adpcm64_decoder.h"
#include "AudioIO\STrackAVEngine.h"

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(IGOControllerFrame)
const long IGOControllerFrame::ID_STATICBITMAP_LOGO = wxNewId();
const long IGOControllerFrame::ID_PANEL_LOGO = wxNewId();
const long IGOControllerFrame::ID_STATICTEXT_RX_STATUS = wxNewId();
const long IGOControllerFrame::ID_BUTTON_PORT_STATUS = wxNewId();
const long IGOControllerFrame::ID_BUTTON_STREAM_STATUS = wxNewId();
const long IGOControllerFrame::ID_BUTTON_SYNC_STATUS = wxNewId();
const long IGOControllerFrame::ID_PANEL_STATUS = wxNewId();
const long IGOControllerFrame::ID_STATICTEXT_SERIAL_PORT = wxNewId();
const long IGOControllerFrame::ID_CHOICE_SERIAL_PORT_NAME = wxNewId();
const long IGOControllerFrame::ID_TEXTCTRL_PORT_DESC = wxNewId();
const long IGOControllerFrame::ID_BUTTON_PORT_SCAN = wxNewId();
const long IGOControllerFrame::ID_CHOICE_SERIAL_PORT_SPEED = wxNewId();
const long IGOControllerFrame::ID_BUTTON_PORT_ACTIVATE = wxNewId();
const long IGOControllerFrame::ID_BUTTON_PORT_DEACTIVATE = wxNewId();
const long IGOControllerFrame::ID_PANEL_CONNECTIONS = wxNewId();
const long IGOControllerFrame::ID_TEXTCTRL_LOG = wxNewId();
const long IGOControllerFrame::ID_PANEL_LOG = wxNewId();
const long IGOControllerFrame::ID_STATICTEXT_RX_FREQ = wxNewId();
const long IGOControllerFrame::ID_COMBO_FREQ_100MHZ = wxNewId();
const long IGOControllerFrame::ID_COMBO_FREQ_10MHZ = wxNewId();
const long IGOControllerFrame::ID_COMBO_FREQ_1MHZ = wxNewId();
const long IGOControllerFrame::ID_STATICTEXT_DOT = wxNewId();
const long IGOControllerFrame::ID_COMBO_FREQ_100KHZ = wxNewId();
const long IGOControllerFrame::ID_COMBO_FREQ_10KHZ = wxNewId();
const long IGOControllerFrame::ID_COMBO_FREQ_1KHZ = wxNewId();
const long IGOControllerFrame::ID_PANEL_RX_FREQ = wxNewId();
const long IGOControllerFrame::ID_PANEL_RXCTRL = wxNewId();
const long IGOControllerFrame::ID_STATICTEXT_SYNC_EVENTS = wxNewId();
const long IGOControllerFrame::ID_STATICTEXT_BUFFER_EVENTS = wxNewId();
const long IGOControllerFrame::ID_PANEL_CENTRE = wxNewId();
const long IGOControllerFrame::ID_PANEL_MAIN_UI = wxNewId();
const long IGOControllerFrame::idMenuQuit = wxNewId();
const long IGOControllerFrame::idMenuAbout = wxNewId();
const long IGOControllerFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(IGOControllerFrame,wxFrame)
    //(*EventTable(IGOControllerFrame)
    //*)
	EVT_THREAD(IGORX_EVENT, IGOControllerFrame::OnSerialIOThreadEvent)
END_EVENT_TABLE()

IGOControllerFrame::IGOControllerFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(IGOControllerFrame)
    wxBoxSizer* BoxSizerPanelCentre;
    wxMenuItem* MenuItem2;
    wxBoxSizer* BoxSizerMainFrame;
    wxBoxSizer* BoxSizerMainUI;
    wxMenuItem* MenuItem1;
    wxBoxSizer* BoxSizerStatus;
    wxMenu* Menu1;
    wxBoxSizer* BoxSizerConnect;
    wxBoxSizer* BoxSizerRXFreq;
    wxBoxSizer* BoxSizerScan;
    wxBoxSizer* BoxSizerFreqDwn;
    wxBoxSizer* BoxSizerDiagnostics;
    wxBoxSizer* BoxSizerRXControl;
    wxBoxSizer* BoxSizerPanelConnections;
    wxBoxSizer* BoxSizerLogo;
    wxMenuBar* MenuBar1;
    wxMenu* Menu2;
    wxBoxSizer* BoxSizerPanelLog;
    wxBoxSizer* BoxSizerFreqUp;

    Create(parent, wxID_ANY, _("IGO Receiver test"), wxDefaultPosition, wxDefaultSize, wxCAPTION|wxCLOSE_BOX|wxMINIMIZE_BOX, _T("wxID_ANY"));
    {
    	wxIcon FrameIcon;
    	FrameIcon.CopyFromBitmap(wxBitmap(wxImage(_T(".\\UI\\CommeshIcon.png"))));
    	SetIcon(FrameIcon);
    }
    BoxSizerMainFrame = new wxBoxSizer(wxHORIZONTAL);
    PanelMainUI = new RimPanel(this, ID_PANEL_MAIN_UI, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL, _T("ID_PANEL_MAIN_UI"));
    BoxSizerMainUI = new wxBoxSizer(wxVERTICAL);
    PanelLogo = new RimPanel(PanelMainUI, ID_PANEL_LOGO, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL, _T("ID_PANEL_LOGO"));
    BoxSizerLogo = new wxBoxSizer(wxHORIZONTAL);
    BoxSizerLogo->Add(-1,-1,1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    StaticBitmapLogo = new wxStaticBitmap(PanelLogo, ID_STATICBITMAP_LOGO, wxBitmap(wxImage(_T("UI\\CommeshLogo.png"))), wxDefaultPosition, wxDefaultSize, wxNO_BORDER, _T("ID_STATICBITMAP_LOGO"));
    BoxSizerLogo->Add(StaticBitmapLogo, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 5);
    BoxSizerLogo->Add(5,-1,0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 0);
    PanelLogo->SetSizer(BoxSizerLogo);
    BoxSizerLogo->Fit(PanelLogo);
    BoxSizerLogo->SetSizeHints(PanelLogo);
    BoxSizerMainUI->Add(PanelLogo, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 4);
    BoxSizerMainUI->Add(-1,5,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    PanelStatus = new RimPanel(PanelMainUI, ID_PANEL_STATUS, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL_STATUS"));
    BoxSizerStatus = new wxBoxSizer(wxHORIZONTAL);
    StaticTextRxStatus = new wxStaticText(PanelStatus, ID_STATICTEXT_RX_STATUS, _("serial status"), wxDefaultPosition, wxSize(90,-1), wxALIGN_LEFT, _T("ID_STATICTEXT_RX_STATUS"));
    StaticTextRxStatus->SetBackgroundColour(wxColour(210,210,210));
    wxFont StaticTextRxStatusFont(10,wxSWISS,wxFONTSTYLE_NORMAL,wxBOLD,false,wxEmptyString,wxFONTENCODING_DEFAULT);
    StaticTextRxStatus->SetFont(StaticTextRxStatusFont);
    BoxSizerStatus->Add(StaticTextRxStatus, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    BoxSizerStatus->Add(120,-1,1, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 0);
    ButtonPortStatus = new GButton(PanelStatus, ID_BUTTON_PORT_STATUS, _("port"), wxDefaultPosition, wxSize(60,30), 0, wxDefaultValidator, _T("ID_BUTTON_PORT_STATUS"));
    BoxSizerStatus->Add(ButtonPortStatus, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerStatus->Add(1,-1,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    ButtonStreamStatus = new GButton(PanelStatus, ID_BUTTON_STREAM_STATUS, _("stream"), wxDefaultPosition, wxSize(60,30), 0, wxDefaultValidator, _T("ID_BUTTON_STREAM_STATUS"));
    BoxSizerStatus->Add(ButtonStreamStatus, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerStatus->Add(1,-1,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    ButtonSyncStatus = new GButton(PanelStatus, ID_BUTTON_SYNC_STATUS, _("sync"), wxDefaultPosition, wxSize(60,30), 0, wxDefaultValidator, _T("ID_BUTTON_SYNC_STATUS"));
    BoxSizerStatus->Add(ButtonSyncStatus, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerStatus->Add(2,-1,0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 0);
    PanelStatus->SetSizer(BoxSizerStatus);
    BoxSizerStatus->Fit(PanelStatus);
    BoxSizerStatus->SetSizeHints(PanelStatus);
    BoxSizerMainUI->Add(PanelStatus, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 4);
    BoxSizerMainUI->Add(-1,20,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    PanelConnections = new RimPanel(PanelMainUI, ID_PANEL_CONNECTIONS, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL, _T("ID_PANEL_CONNECTIONS"));
    BoxSizerPanelConnections = new wxBoxSizer(wxVERTICAL);
    BoxSizerScan = new wxBoxSizer(wxHORIZONTAL);
    StaticTextSerialPort = new wxStaticText(PanelConnections, ID_STATICTEXT_SERIAL_PORT, _(" serial port"), wxDefaultPosition, wxSize(90,-1), wxALIGN_LEFT, _T("ID_STATICTEXT_SERIAL_PORT"));
    StaticTextSerialPort->SetBackgroundColour(wxColour(210,210,210));
    wxFont StaticTextSerialPortFont(10,wxSWISS,wxFONTSTYLE_NORMAL,wxBOLD,false,wxEmptyString,wxFONTENCODING_DEFAULT);
    StaticTextSerialPort->SetFont(StaticTextSerialPortFont);
    BoxSizerScan->Add(StaticTextSerialPort, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    BoxSizerScan->Add(75,-1,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    ChoiceSerialPortName = new wxChoice(PanelConnections, ID_CHOICE_SERIAL_PORT_NAME, wxDefaultPosition, wxSize(120,22), 0, 0, 0, wxDefaultValidator, _T("ID_CHOICE_SERIAL_PORT_NAME"));
    BoxSizerScan->Add(ChoiceSerialPortName, 1, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerScan->Add(50,-1,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    TextCtrlPortDescription = new wxTextCtrl(PanelConnections, ID_TEXTCTRL_PORT_DESC, wxEmptyString, wxDefaultPosition, wxSize(300,22), wxTE_READONLY, wxDefaultValidator, _T("ID_TEXTCTRL_PORT_DESC"));
    BoxSizerScan->Add(TextCtrlPortDescription, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerScan->Add(50,-1,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    BoxSizerPanelConnections->Add(BoxSizerScan, 0, wxTOP|wxLEFT|wxRIGHT|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerConnect = new wxBoxSizer(wxHORIZONTAL);
    ButtonPortScan = new wxButton(PanelConnections, ID_BUTTON_PORT_SCAN, _("scan ports"), wxDefaultPosition, wxSize(90,22), 0, wxDefaultValidator, _T("ID_BUTTON_PORT_SCAN"));
    BoxSizerConnect->Add(ButtonPortScan, 0, wxTOP|wxBOTTOM|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerConnect->Add(75,-1,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    ChoiceSerialPortSpeed = new wxChoice(PanelConnections, ID_CHOICE_SERIAL_PORT_SPEED, wxDefaultPosition, wxSize(120,22), 0, 0, 0, wxDefaultValidator, _T("ID_CHOICE_SERIAL_PORT_SPEED"));
    ChoiceSerialPortSpeed->Append(_("230400 baud"));
    ChoiceSerialPortSpeed->Append(_("460800 baud"));
    ChoiceSerialPortSpeed->SetSelection( ChoiceSerialPortSpeed->Append(_("921600 baud")) );
    BoxSizerConnect->Add(ChoiceSerialPortSpeed, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerConnect->Add(50,-1,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    ButtonPortActivvate = new wxButton(PanelConnections, ID_BUTTON_PORT_ACTIVATE, _("connect"), wxDefaultPosition, wxSize(100,22), 0, wxDefaultValidator, _T("ID_BUTTON_PORT_ACTIVATE"));
    BoxSizerConnect->Add(ButtonPortActivvate, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    ButtonPortDeActivvate = new wxButton(PanelConnections, ID_BUTTON_PORT_DEACTIVATE, _("disconnect"), wxDefaultPosition, wxSize(100,22), 0, wxDefaultValidator, _T("ID_BUTTON_PORT_DEACTIVATE"));
    BoxSizerConnect->Add(ButtonPortDeActivvate, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerConnect->Add(50,-1,1, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    BoxSizerPanelConnections->Add(BoxSizerConnect, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 2);
    PanelConnections->SetSizer(BoxSizerPanelConnections);
    BoxSizerPanelConnections->Fit(PanelConnections);
    BoxSizerPanelConnections->SetSizeHints(PanelConnections);
    BoxSizerMainUI->Add(PanelConnections, 0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 4);
    BoxSizerMainUI->Add(-1,10,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    PanelLog = new RimPanel(PanelMainUI, ID_PANEL_LOG, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL, _T("ID_PANEL_LOG"));
    BoxSizerPanelLog = new wxBoxSizer(wxHORIZONTAL);
    TextCtrlLog = new wxTextCtrl(PanelLog, ID_TEXTCTRL_LOG, _("LOG MESSAGES"), wxDefaultPosition, wxSize(250,100), wxTE_MULTILINE|wxTE_READONLY, wxDefaultValidator, _T("ID_TEXTCTRL_LOG"));
    TextCtrlLog->SetBackgroundColour(wxColour(225,225,225));
    BoxSizerPanelLog->Add(TextCtrlLog, 1, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 5);
    PanelLog->SetSizer(BoxSizerPanelLog);
    BoxSizerPanelLog->Fit(PanelLog);
    BoxSizerPanelLog->SetSizeHints(PanelLog);
    BoxSizerMainUI->Add(PanelLog, 1, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 4);
    BoxSizerMainUI->Add(-1,10,0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    PanelRXControl = new wxPanel(PanelMainUI, ID_PANEL_RXCTRL, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL, _T("ID_PANEL_RXCTRL"));
    BoxSizerRXControl = new wxBoxSizer(wxHORIZONTAL);
    PanelRXFreq = new RimPanel(PanelRXControl, ID_PANEL_RX_FREQ, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL, _T("ID_PANEL_RX_FREQ"));
    BoxSizerRXFreq = new wxBoxSizer(wxVERTICAL);
    BoxSizerFreqUp = new wxBoxSizer(wxHORIZONTAL);
    StaticTextRxFreq = new wxStaticText(PanelRXFreq, ID_STATICTEXT_RX_FREQ, _(" rx frequency"), wxDefaultPosition, wxSize(90,-1), wxALIGN_LEFT, _T("ID_STATICTEXT_RX_FREQ"));
    StaticTextRxFreq->SetBackgroundColour(wxColour(210,210,210));
    wxFont StaticTextRxFreqFont(10,wxSWISS,wxFONTSTYLE_NORMAL,wxBOLD,false,wxEmptyString,wxFONTENCODING_DEFAULT);
    StaticTextRxFreq->SetFont(StaticTextRxFreqFont);
    BoxSizerFreqUp->Add(StaticTextRxFreq, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    BoxSizerFreqUp->Add(75,-1,0, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 0);
    m_hMHZ = new wxComboBox(PanelRXFreq, ID_COMBO_FREQ_100MHZ, wxEmptyString, wxDefaultPosition, wxSize(50,20), 0, 0, wxCB_READONLY|wxCB_DROPDOWN, wxDefaultValidator, _T("ID_COMBO_FREQ_100MHZ"));
    BoxSizerFreqUp->Add(m_hMHZ, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    m_dMHZ = new wxComboBox(PanelRXFreq, ID_COMBO_FREQ_10MHZ, wxEmptyString, wxDefaultPosition, wxSize(50,20), 0, 0, wxCB_READONLY|wxCB_DROPDOWN, wxDefaultValidator, _T("ID_COMBO_FREQ_10MHZ"));
    BoxSizerFreqUp->Add(m_dMHZ, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    m_uMHZ = new wxComboBox(PanelRXFreq, ID_COMBO_FREQ_1MHZ, wxEmptyString, wxDefaultPosition, wxSize(50,20), 0, 0, wxCB_READONLY|wxCB_DROPDOWN, wxDefaultValidator, _T("ID_COMBO_FREQ_1MHZ"));
    BoxSizerFreqUp->Add(m_uMHZ, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    StaticTextDot = new wxStaticText(PanelRXFreq, ID_STATICTEXT_DOT, _("."), wxDefaultPosition, wxSize(-1,20), 0, _T("ID_STATICTEXT_DOT"));
    BoxSizerFreqUp->Add(StaticTextDot, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    m_hKHZ = new wxComboBox(PanelRXFreq, ID_COMBO_FREQ_100KHZ, wxEmptyString, wxDefaultPosition, wxSize(50,20), 0, 0, wxCB_READONLY|wxCB_DROPDOWN, wxDefaultValidator, _T("ID_COMBO_FREQ_100KHZ"));
    BoxSizerFreqUp->Add(m_hKHZ, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    m_dKHZ = new wxComboBox(PanelRXFreq, ID_COMBO_FREQ_10KHZ, wxEmptyString, wxDefaultPosition, wxSize(50,20), 0, 0, wxCB_READONLY|wxCB_DROPDOWN, wxDefaultValidator, _T("ID_COMBO_FREQ_10KHZ"));
    BoxSizerFreqUp->Add(m_dKHZ, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    m_uKHZ = new wxComboBox(PanelRXFreq, ID_COMBO_FREQ_1KHZ, wxEmptyString, wxDefaultPosition, wxSize(50,20), 0, 0, wxCB_READONLY|wxCB_DROPDOWN, wxDefaultValidator, _T("ID_COMBO_FREQ_1KHZ"));
    BoxSizerFreqUp->Add(m_uKHZ, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 1);
    BoxSizerFreqUp->Add(-1,-1,1, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 0);
    BoxSizerRXFreq->Add(BoxSizerFreqUp, 1, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerFreqDwn = new wxBoxSizer(wxHORIZONTAL);
    BoxSizerRXFreq->Add(BoxSizerFreqDwn, 1, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 2);
    PanelRXFreq->SetSizer(BoxSizerRXFreq);
    BoxSizerRXFreq->Fit(PanelRXFreq);
    BoxSizerRXFreq->SetSizeHints(PanelRXFreq);
    BoxSizerRXControl->Add(PanelRXFreq, 1, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 0);
    PanelRXControl->SetSizer(BoxSizerRXControl);
    BoxSizerRXControl->Fit(PanelRXControl);
    BoxSizerRXControl->SetSizeHints(PanelRXControl);
    BoxSizerMainUI->Add(PanelRXControl, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 4);
    PanelCentre = new RimPanel(PanelMainUI, ID_PANEL_CENTRE, wxDefaultPosition, wxDefaultSize, wxNO_BORDER|wxTAB_TRAVERSAL, _T("ID_PANEL_CENTRE"));
    BoxSizerPanelCentre = new wxBoxSizer(wxVERTICAL);
    BoxSizerDiagnostics = new wxBoxSizer(wxVERTICAL);
    StaticTextSyncEvents = new wxStaticText(PanelCentre, ID_STATICTEXT_SYNC_EVENTS, _(" sync lost count:"), wxDefaultPosition, wxSize(120,20), 0, _T("ID_STATICTEXT_SYNC_EVENTS"));
    StaticTextSyncEvents->SetBackgroundColour(wxColour(210,210,210));
    BoxSizerDiagnostics->Add(StaticTextSyncEvents, 0, wxTOP|wxLEFT|wxRIGHT|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 2);
    StaticTextBufferEvents = new wxStaticText(PanelCentre, ID_STATICTEXT_BUFFER_EVENTS, _(" buffer events"), wxDefaultPosition, wxSize(120,20), 0, _T("ID_STATICTEXT_BUFFER_EVENTS"));
    StaticTextBufferEvents->SetBackgroundColour(wxColour(210,210,210));
    wxFont StaticTextBufferEventsFont(10,wxSWISS,wxFONTSTYLE_NORMAL,wxNORMAL,false,_T("Arial"),wxFONTENCODING_DEFAULT);
    StaticTextBufferEvents->SetFont(StaticTextBufferEventsFont);
    BoxSizerDiagnostics->Add(StaticTextBufferEvents, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 2);
    BoxSizerPanelCentre->Add(BoxSizerDiagnostics, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 5);
    PanelCentre->SetSizer(BoxSizerPanelCentre);
    BoxSizerPanelCentre->Fit(PanelCentre);
    BoxSizerPanelCentre->SetSizeHints(PanelCentre);
    BoxSizerMainUI->Add(PanelCentre, 1, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_TOP, 4);
    PanelMainUI->SetSizer(BoxSizerMainUI);
    BoxSizerMainUI->Fit(PanelMainUI);
    BoxSizerMainUI->SetSizeHints(PanelMainUI);
    BoxSizerMainFrame->Add(PanelMainUI, 1, wxALL|wxALIGN_LEFT|wxALIGN_TOP, 2);
    SetSizer(BoxSizerMainFrame);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);
    BoxSizerMainFrame->Fit(this);
    BoxSizerMainFrame->SetSizeHints(this);
    Center();

    Connect(ID_CHOICE_SERIAL_PORT_NAME,wxEVT_COMMAND_CHOICE_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnChoiceSerialPortNameSelect);
    Connect(ID_BUTTON_PORT_SCAN,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&IGOControllerFrame::OnButtonPortScanClick);
    Connect(ID_CHOICE_SERIAL_PORT_SPEED,wxEVT_COMMAND_CHOICE_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnChoiceSerialPortSpeedSelect);
    Connect(ID_BUTTON_PORT_ACTIVATE,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&IGOControllerFrame::OnButtonPortActivvateClick);
    Connect(ID_BUTTON_PORT_DEACTIVATE,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&IGOControllerFrame::OnButtonPortDeActivvateClick);
    Connect(ID_COMBO_FREQ_100MHZ,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnFreqSelected);
    Connect(ID_COMBO_FREQ_10MHZ,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnFreqSelected);
    Connect(ID_COMBO_FREQ_1MHZ,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnFreqSelected);
    Connect(ID_COMBO_FREQ_100KHZ,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnFreqSelected);
    Connect(ID_COMBO_FREQ_10KHZ,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnFreqSelected);
    Connect(ID_COMBO_FREQ_1KHZ,wxEVT_COMMAND_COMBOBOX_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnFreqSelected);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&IGOControllerFrame::OnAbout);
    //*)

	ButtonPortStatus->setAsLED(true);
	ButtonPortStatus->enable(false);
	ButtonStreamStatus->setAsLED(true);
	ButtonStreamStatus->enable(false);
	ButtonSyncStatus->setAsLED(true);
	ButtonSyncStatus->enable(false);

	InitSerialIO();
	if (gSerialIO)
	{
		gSerialIO->SetParent(this);
		RefreshPortsList();
	
		if (gAVEngine)
		{
			gAVEngine->SetParent(this);
		}
	}

	BuildFreqSelectionUI();
	SetUIStatus(PORT_IDLE);
}

IGOControllerFrame::~IGOControllerFrame()
{
    //(*Destroy(IGOControllerFrame)
    //*)

	DeinitSerialIO();
}

void IGOControllerFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void IGOControllerFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void IGOControllerFrame::OnChoiceSerialPortNameSelect(wxCommandEvent& event)
{
	UpdatePortDescription();
}

void IGOControllerFrame::OnChoiceSerialPortSpeedSelect(wxCommandEvent& event)
{
}

void IGOControllerFrame::OnButtonPortActivvateClick(wxCommandEvent& event)
{
	TextCtrlLog->Clear();

	int pnIndex = ChoiceSerialPortName->GetSelection();
	int psIndex = ChoiceSerialPortSpeed->GetSelection();

	if ((pnIndex < 0) || (psIndex < 0))
		return;

	SerialPortMap el = mComPorts[pnIndex];

	int bRate = -1;
	switch (psIndex)
	{
		case 0:{
			bRate = 230400;
		}
		break;

		case 1:	{
			bRate = 460800;
		}
		break;

		case 2:{
			bRate = 921600;
		}
		break;

		default:{
			bRate = 921600;
		}
			break;
	}

	gSerialIO->OpenSerialPort(el.address, bRate, 1024);
}

void IGOControllerFrame::OnButtonPortDeActivvateClick(wxCommandEvent& event)
{
    gSerialIO->CloseSerialPort();
}

void IGOControllerFrame::OnButtonPortScanClick(wxCommandEvent& event)
{
	RefreshPortsList();
}

void IGOControllerFrame::RefreshPortsList()
{
	ChoiceSerialPortName->Clear();
	mComPorts.clear();
	mComPorts = gSerialIO->GetSerialPorts();

	size_t noPorts = mComPorts.size();

	for (size_t ptIdx = 0; ptIdx < noPorts; ptIdx++)
	{
		SerialPortMap pm = mComPorts[ptIdx];
		ChoiceSerialPortName->Append(pm.address);
	}

	ChoiceSerialPortName->SetSelection(0);
	UpdatePortDescription();

}

void IGOControllerFrame::UpdatePortDescription()
{
	int selPtIdx = ChoiceSerialPortName->GetSelection();

	if (selPtIdx < 0)
		return;

	SerialPortMap el = mComPorts[selPtIdx];
	TextCtrlPortDescription->SetValue(el.description);
}


void IGOControllerFrame::BuildFreqSelectionUI()
{
	wxString depthString;
	for (size_t depthIdx = 0; depthIdx < 10; depthIdx++)
	{
		depthString.Printf(wxT("%d"), depthIdx);
		m_hMHZ->Append(depthString);
		m_dMHZ->Append(depthString);
		m_uMHZ->Append(depthString);
		m_hKHZ->Append(depthString);
		m_dKHZ->Append(depthString);
		m_uKHZ->Append(depthString);
	}

	m_hMHZ->SetValue(wxT("8"));
	m_hMHZ->Enable(false);

	m_dMHZ->SetValue(wxT("6"));
	m_dMHZ->Enable(false);

	m_uMHZ->SetValue(wxT("0"));
	m_uMHZ->Enable(true);

	m_hKHZ->SetValue(wxT("0"));
	m_hKHZ->Enable(false);

	m_dKHZ->SetValue(wxT("0"));
	m_dKHZ->Enable(false);

	m_uKHZ->SetValue(wxT("0"));
	m_uKHZ->Enable(false);

}

void 
IGOControllerFrame::OnFreqSelected(wxCommandEvent& event)
{
	ChangeFrequency();
}

void IGOControllerFrame::ChangeFrequency()
{
	int retVal = 0;

	long hmhz = 0;
	long dmhz = 0;
	long umhz = 0;
	long hkhz = 0;

	m_hMHZ->GetValue().ToLong(&hmhz);
	m_dMHZ->GetValue().ToLong(&dmhz);
	m_uMHZ->GetValue().ToLong(&umhz);
	m_hKHZ->GetValue().ToLong(&hkhz);

	retVal = (int)(hmhz * 10000 + dmhz * 1000 + umhz * 100 + hkhz * 10);

	uint8_t dMHz = (uint8_t)umhz;

	IGOSysCommand cmd;
	cmd.cmdType = 2;
	cmd.cmdValue = dMHz;
	gSerialIO->SendCommand(cmd);
}
 
void
IGOControllerFrame::OnSerialIOThreadEvent(wxThreadEvent& event)
{
	IGOThreadEvent ePl = event.GetPayload<IGOThreadEvent>();

	switch (ePl.eventID)
	{
		case UART_OPENING:
		{

		}
		break;

		case UART_FAIL:
		{

		}
		break;

		case UART_OPEN:
		{
			ButtonPortStatus->setStatus(true);
			SetUIStatus(PORT_OPEN);
		}
		break;

		case UART_RUNNING:
		{

		}
		break;

		case UART_STOPPING:
		{

		}
		break;

		case UART_STOPPED:
		{
			ButtonPortStatus->setStatus(false);
		}
		break;

		case UART_CLOSING:
		{

		}
		break;

		case UART_CLOSED:
		{
			ButtonPortStatus->setStatus(false);
			ButtonSyncStatus->setStatus(false);
			ButtonStreamStatus->setStatus(false);
			SetUIStatus(PORT_IDLE);
		}
		break;

		case DATA_OK:
		{
			ButtonStreamStatus->setStatus(true);
		}
		break;

		case DATA_KO:
		{
			ButtonStreamStatus->setStatus(false);
			ButtonSyncStatus->setStatus(false);
		}
		break;

		case RX_SYNCED_OK:
		{
			ButtonSyncStatus->setStatus(true);
		}
		break;

		case RX_SYNCED_KO:
		{
			ButtonSyncStatus->setStatus(false);
			wxString syncMsg;
			syncMsg.Printf(_T(" sync lost count:  %d"), (int)ePl.eventCounter);
			StaticTextSyncEvents->SetLabel(syncMsg);
		}
		break;

		case AUDIO_BUF_UNDER:
		{
			wxString bufMsg;
			bufMsg.Printf(_T(" buffer events:  %d"), (int)ePl.eventCounter);
			StaticTextBufferEvents->SetLabel(bufMsg);
		}
		break;
	}

	WriteLogMsg(ePl.eventMessage + wxT("\n"));
}

void
IGOControllerFrame::WriteLogMsg(wxString msg)
{
	TextCtrlLog->AppendText(wxT("\n") + msg);
}


void 
IGOControllerFrame::SetUIStatus(ui_stat status)
{
	switch (status)
	{
		case PORT_IDLE:
		{
			ButtonPortActivvate->Enable(true);
			ButtonPortDeActivvate->Enable(false);
			ButtonPortScan->Enable(true);
			ChoiceSerialPortName->Enable(true);
			ChoiceSerialPortSpeed->Enable(true);
		}
		break;

		case PORT_FAIL:
		{
		}
		break;

		case PORT_OPEN:
		{
			ButtonPortActivvate->Enable(false);
			ButtonPortDeActivvate->Enable(true);
			ButtonPortScan->Enable(false);
			ChoiceSerialPortName->Enable(false);
			ChoiceSerialPortSpeed->Enable(false);
		}
		break;

		case PORT_STREAM:
		{
		}
		break;

		case PORT_NOSTREAM:
		{
		}
		break;

		case RX_SYNC:
		{
		}
		break;

		case RX_NOSYNC:
		{
		}
		break;
	}
}