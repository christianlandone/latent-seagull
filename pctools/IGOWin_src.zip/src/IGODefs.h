#ifndef IGODEFS_H
#define IGODEFS_H


#define IGORX_EVENT wxID_HIGHEST + 1

//processes ID
typedef enum {
	AUDIO_THREAD = 0,
	SERIAL_THREAD
} procid_t;

typedef enum {
	DEBUG_EVT = 0,
	CONTROL_EVT
} eventtype_t;

typedef enum {
	UART_OPENING = 0,
	UART_FAIL,
	UART_OPEN,
	UART_RUNNING,
	UART_STOPPING,
	UART_STOPPED,
	UART_CLOSING,
	UART_CLOSED,
	DATA_OK,
	DATA_KO,
	RX_SYNCED_OK,
	RX_SYNCED_KO,
	TX_FOUND_OK,
	TX_FOUND_KO,
	AUDIO_BUF_UNDER
} eventid_t;

typedef struct IGOThreadEvent {
	procid_t    processID;
	eventtype_t eventType;
	eventid_t  eventID;
	float  eventRange;
	float  eventCounter;
	wxString eventMessage;
	wxString debugInfo;
	bool threadFinished;
}IGOThreadEvent;


#define G722_DATA_LENGTH 60
#define SERIAL_HEADER_LENGTH 5
#define RX_HEADER_LENGTH 4
#define SERIAL_PACKET_LENGTH (SERIAL_HEADER_LENGTH+RX_HEADER_LENGTH+G722_DATA_LENGTH)

#endif
