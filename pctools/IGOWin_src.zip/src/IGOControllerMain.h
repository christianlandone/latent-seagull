/***************************************************************
 * Name:      IGOControllerMain.h
 * Purpose:   Defines Application Frame
 * Author:    clandone ()
 * Created:   2017-09-20
 * Copyright: clandone ()
 * License:
 **************************************************************/

#ifndef IGOCONTROLLERMAIN_H
#define IGOCONTROLLERMAIN_H

//(*Headers(IGOControllerFrame)
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/menu.h>
#include <wx/textctrl.h>
#include <wx/panel.h>
#include <wx/choice.h>
#include <wx/statbmp.h>
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/combobox.h>
#include <wx/statusbr.h>
//*)

#include "widgets\RimPanel.h"
#include "widgets\GButton.h"
#include "IGODefs.h"

struct SerialPortMap;

typedef enum {
	PORT_IDLE = 0,
	PORT_FAIL,
	PORT_OPEN,
	PORT_STREAM,
	PORT_NOSTREAM,
	RX_SYNC,
	RX_NOSYNC
} ui_stat;


class IGOControllerFrame: public wxFrame
{
    public:

        IGOControllerFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~IGOControllerFrame();

    private:

        //(*Handlers(IGOControllerFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnChoiceSerialPortNameSelect(wxCommandEvent& event);
        void OnChoiceSerialPortSpeedSelect(wxCommandEvent& event);
        void OnButtonPortActivvateClick(wxCommandEvent& event);
        void OnButtonPortScanClick(wxCommandEvent& event);
        void OnButtonPortDeActivvateClick(wxCommandEvent& event);
        void OnFreqSelected(wxCommandEvent& event);
        //*)

		void OnSerialIOThreadEvent(wxThreadEvent& event);
		void WriteLogMsg(wxString msg);

        //(*Identifiers(IGOControllerFrame)
        static const long ID_STATICBITMAP_LOGO;
        static const long ID_PANEL_LOGO;
        static const long ID_STATICTEXT_RX_STATUS;
        static const long ID_BUTTON_PORT_STATUS;
        static const long ID_BUTTON_STREAM_STATUS;
        static const long ID_BUTTON_SYNC_STATUS;
        static const long ID_PANEL_STATUS;
        static const long ID_STATICTEXT_SERIAL_PORT;
        static const long ID_CHOICE_SERIAL_PORT_NAME;
        static const long ID_TEXTCTRL_PORT_DESC;
        static const long ID_BUTTON_PORT_SCAN;
        static const long ID_CHOICE_SERIAL_PORT_SPEED;
        static const long ID_BUTTON_PORT_ACTIVATE;
        static const long ID_BUTTON_PORT_DEACTIVATE;
        static const long ID_PANEL_CONNECTIONS;
        static const long ID_TEXTCTRL_LOG;
        static const long ID_PANEL_LOG;
        static const long ID_STATICTEXT_RX_FREQ;
        static const long ID_COMBO_FREQ_100MHZ;
        static const long ID_COMBO_FREQ_10MHZ;
        static const long ID_COMBO_FREQ_1MHZ;
        static const long ID_STATICTEXT_DOT;
        static const long ID_COMBO_FREQ_100KHZ;
        static const long ID_COMBO_FREQ_10KHZ;
        static const long ID_COMBO_FREQ_1KHZ;
        static const long ID_PANEL_RX_FREQ;
        static const long ID_PANEL_RXCTRL;
        static const long ID_STATICTEXT_SYNC_EVENTS;
        static const long ID_STATICTEXT_BUFFER_EVENTS;
        static const long ID_PANEL_CENTRE;
        static const long ID_PANEL_MAIN_UI;
        static const long idMenuQuit;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(IGOControllerFrame)
        wxComboBox* m_hMHZ;
        wxButton* ButtonPortActivvate;
        wxStaticText* StaticTextSerialPort;
        GButton* ButtonSyncStatus;
        wxTextCtrl* TextCtrlPortDescription;
        wxStaticText* StaticTextRxFreq;
        wxStaticText* StaticTextDot;
        RimPanel* PanelConnections;
        wxComboBox* m_uMHZ;
        RimPanel* PanelRXFreq;
        wxChoice* ChoiceSerialPortSpeed;
        wxComboBox* m_dMHZ;
        RimPanel* PanelMainUI;
        wxTextCtrl* TextCtrlLog;
        wxStaticText* StaticTextRxStatus;
        GButton* ButtonPortStatus;
        wxPanel* PanelRXControl;
        wxComboBox* m_hKHZ;
        RimPanel* PanelLogo;
        RimPanel* PanelLog;
        RimPanel* PanelStatus;
        wxButton* ButtonPortDeActivvate;
        wxComboBox* m_dKHZ;
        wxStatusBar* StatusBar1;
        wxStaticText* StaticTextSyncEvents;
        wxStaticBitmap* StaticBitmapLogo;
        wxButton* ButtonPortScan;
        RimPanel* PanelCentre;
        wxStaticText* StaticTextBufferEvents;
        GButton* ButtonStreamStatus;
        wxChoice* ChoiceSerialPortName;
        wxComboBox* m_uKHZ;
        //*)

        DECLARE_EVENT_TABLE()

	protected:
		void RefreshPortsList();
		void UpdatePortDescription();

		void BuildFreqSelectionUI();
		void ChangeFrequency();

		void SetUIStatus(ui_stat status);

		std::vector<SerialPortMap> mComPorts;
};

#endif // IGOCONTROLLERMAIN_H
