#include "CommandsQueue.h"

/////////////////////////////////////////////////////////////
//Parameters Queue
CommandsQueue::CommandsQueue(int maxLen):
   mBufferSize(maxLen)
{
    mBuffer = new IGOSysCommand[mBufferSize];
    Clear();
}

// destructor
CommandsQueue::~CommandsQueue()
{
   delete [] mBuffer;
}

void CommandsQueue::Clear()
{
   mStart = 0;
   mEnd = 0;
}

// Add a message to the end of the queue.  Return false if the
// queue was full.
bool CommandsQueue::Put(IGOSysCommand &msg)
{
   int len = (mEnd + mBufferSize - mStart) % mBufferSize;

   // Never completely fill the queue, because then the
   // state is ambiguous (mStart==mEnd)
   if (len >= mBufferSize-1)
      return false;

   mBuffer[mEnd] = msg;
   mEnd = (mEnd+1)%mBufferSize;

   return true;
}

// Get the next message from the start of the queue.
// Return false if the queue was empty.
bool CommandsQueue::Get(IGOSysCommand &msg)
{
   int len = (mEnd + mBufferSize - mStart) % mBufferSize;

   if (len == 0)
   {
       msg = mLastValid;
       return false;
   }

   msg = mBuffer[mStart];
   mStart = (mStart+1)%mBufferSize;
   mLastValid = msg;

   return true;
}

