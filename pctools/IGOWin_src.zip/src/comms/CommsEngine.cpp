#include "CommsEngine.h"
#include "..\IGOControllerMain.h"
#include "..\g722\adpcm64_coder.h"
#include "..\g722\adpcm64_decoder.h"
#include "..\g722\WavFileWriter.h"
#include "..\AudioIO\STrackAVEngine.h"

std::unique_ptr<SerialIO> ugSerialIO;
SerialIO *gSerialIO{};


class SerialIOThread: public wxThread {
public:
	SerialIOThread() :wxThread(wxTHREAD_JOINABLE) {}
	ExitCode Entry() override;
};

void InitSerialIO()
{
	ugSerialIO.reset(safenew SerialIO());
	gSerialIO = ugSerialIO.get();	
}

void DeinitSerialIO()
{
	ugSerialIO.reset();
}

SerialIO::SerialIO()
:mSPortHandle(NULL)
,mParent(NULL)
,bIsStopped(true)
,mIsSafe(true)
,mComQueue(128)
{
	//ctor
	InitAVEngine();
	reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_CLOSED, 0, wxT("serial port closed"));
}

SerialIO::~SerialIO()
{
    //dtor
	StopSerialIO();
	gSerialIO = nullptr;

	DeinitAVEngine();
}

void
SerialIO::SetParent(IGOControllerFrame* parent)
{
	mParent = parent;
}

std::vector<SerialPortMap> 
SerialIO::GetSerialPorts()
{
	mComPorts.clear();

	std::vector<serial::PortInfo> devices_found = serial::list_ports();

	std::vector<serial::PortInfo>::iterator iter = devices_found.begin();

	while (iter != devices_found.end())
	{
		serial::PortInfo device = *iter++;

		SerialPortMap el;
		el.address = device.port.c_str();
		el.description = device.description.c_str();
		el.hardware_id = device.hardware_id.c_str();
		mComPorts.push_back(el);
	}

	return mComPorts;
}

bool 
SerialIO::OpenSerialPort(wxString portName, int portSpeed, int frameSize)
{
	reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_OPENING, 0, wxT("opening serial port"));

	if (bIsStopped == false)
	{
		CloseSerialPort();
	}

	std::string pname = portName.mbc_str();

	try {
		mSPortHandle = new serial::Serial(pname, portSpeed, serial::Timeout::simpleTimeout(1000));
	}
	catch (...)
	{
		reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_FAIL, 0, wxT("failed to open serial port"));
		return false;
	}

	if (mSPortHandle && mSPortHandle->isOpen())
	{
		reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_OPEN, 0, wxT("serial port opened"));

		StartSerialIO();

		return true;
	}

	reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_FAIL,0, wxT("failed to open serial port"));

	return false;
}

bool 
SerialIO::CloseSerialPort()
{
	StopSerialIO();

	if (mSPortHandle)
	{
		delete mSPortHandle;
		mSPortHandle = NULL;
	}

	reportEvent(SERIAL_THREAD, CONTROL_EVT,UART_CLOSED, 0, wxT("serial port closed"));

	return true;
}

void
SerialIO::StartSerialIO()
{
	if (bIsStopped)
	{
		bIsStopped = false;
		mSerialThread = std::make_unique<SerialIOThread>();
		mSerialThread->Create();
		mSerialThread->SetPriority(wxPRIORITY_MAX);
		mSerialThread->Run();
	}
}

void 
SerialIO::StopSerialIO()
{
	reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_STOPPING, 0, wxT("stopping serial port"));

	bIsStopped = true;

	while (mIsSafe == false)
	{
		wxMilliSleep(1);
	}

	if (mSerialThread)
	{
		mSerialThread->Delete();
		mSerialThread.reset();
	}

	reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_STOPPED, 0, wxT("serial port stopped"));
}

void
SerialIO::reportEvent(procid_t processID,
	eventtype_t eventType,
	eventid_t   eventID,
	float value,
	wxString message,
	bool killProcess,
	wxString debugInfo)
{
	if (mParent)
	{
		IGOThreadEvent tevent;
		tevent.processID = processID;
		tevent.eventID = eventID;
		tevent.eventMessage = message;
		tevent.eventCounter = value;
		tevent.threadFinished = killProcess;
		tevent.debugInfo = debugInfo;

		wxThreadEvent event(wxEVT_THREAD, IGORX_EVENT);
		event.SetPayload(tevent);
		wxQueueEvent(mParent, event.Clone());
	}
}

///////////////////////////////////////////////////////////////////////////////////////
//ADC Test procedures
///////////////////////////////////////////////////////////////////////////////////////
int
SerialIO::doSerialIO()
{
	mIsSafe = false;

	size_t packetSize = SERIAL_PACKET_LENGTH;
	uint8_t *bufferIn = new uint8_t[packetSize];
	uint8_t *bufferInAligned = new uint8_t[packetSize];
	size_t readBytes = 0;

	uint8_t* msgBuffer = new uint8_t[128];

	reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_RUNNING, 0, wxT("serial IO started"));

	mSPortHandle->flush();
	gAVEngine->StartRealTime();

	IGOSysCommand msg;
	int commandSize = sizeof(IGOSysCommand);

	bool dataStatus = true;
	bool previousDataStatus = false;
	bool sendDataStatus = false;

	while (bIsStopped == false)
	{
		try {
			readBytes = mSPortHandle->read(bufferIn, packetSize);
		}
		catch (...)
		{
			reportEvent(SERIAL_THREAD, CONTROL_EVT, UART_FAIL, 0, wxT("serial port disconnected"));
			bIsStopped = true;
			break;
		}
	
		if( gAVEngine)
			bool status = gAVEngine->ingestPackets(bufferIn, readBytes);
		
		//send commands in queue
		if (mComQueue.Get(msg))
		{
			memcpy(msgBuffer, &msg, commandSize);
			mSPortHandle->write(msgBuffer, commandSize);
		}

		if (previousDataStatus != (bool)readBytes)
		{
			previousDataStatus = (bool)readBytes;
			sendDataStatus = true;
		}

		if (sendDataStatus)
		{
			if( previousDataStatus )
				reportEvent(SERIAL_THREAD, CONTROL_EVT, DATA_OK, 0, wxT("data available"));
			else
				reportEvent(SERIAL_THREAD, CONTROL_EVT, DATA_KO, 0, wxT("data not available"));

			sendDataStatus = false;
		}
	}

	delete[] bufferIn;
	delete[] bufferInAligned;
	delete[] msgBuffer;
	//fclose(fout);

	gAVEngine->StopRealTime();

	mIsSafe = true; 

	return 0;
}

void 
SerialIO::decodeUartPktsToAudio()
{
	FILE *pfEncoded;
	std::string strpath("out.wav");
	WavFileWriter* writer = new WavFileWriter(strpath, 1, 16000, 1);

	char* headerBuf = new char[SERIAL_HEADER_LENGTH + RX_HEADER_LENGTH];
	
	unsigned short*  buffer_in = new unsigned short[1024];
	unsigned short*  buffer_tmp = new unsigned short[1024];
	short*   buffer_out = new short[1024];
	float*   outframe = new float[1024];
	int read;
	int synced = 0;
	long int pos = 0;

	G722DECODER decoder;
	adpcm64_decode_init(&decoder);

	pfEncoded = fopen("in.adp", "rb");
	if (!pfEncoded)
	{
		return;
	}

	fseek(pfEncoded, 1500, SEEK_SET);
	pos += 1500;

	int syncPos = getSynch(pfEncoded);
	pos += syncPos;

	fseek(pfEncoded, pos + (SERIAL_HEADER_LENGTH+ RX_HEADER_LENGTH), SEEK_SET);
	while ((read = fread((char *)buffer_in, sizeof(short), G722_DATA_LENGTH/2, pfEncoded)) != 0)
	{
		read = adpcm64_unpack_vadim(buffer_in, buffer_tmp, read);
		read = adpcm64_decode_run(&decoder, buffer_tmp, buffer_out, read);

		for (int i = 0; i < read; i++)
		{
			outframe[i] = ((float)buffer_out[i]) / 32767;
		}
		writer->writeAudioFrames(outframe, read);

		fread(headerBuf, sizeof(char), (SERIAL_HEADER_LENGTH + RX_HEADER_LENGTH), pfEncoded);
		if ((headerBuf[0] != 'R') && (headerBuf[1] != 'X'))
		{
			pos = ftell(pfEncoded);
			syncPos = getSynch(pfEncoded);
			pos += syncPos;
			fseek(pfEncoded, pos + (SERIAL_HEADER_LENGTH + RX_HEADER_LENGTH), SEEK_SET);
			
			//mute the output

			for (int i = 0; i < read; i++)
			{
				outframe[i] = 0;
			}
			writer->writeAudioFrames(outframe, read);
		}
	}

	fclose(pfEncoded);
	delete writer;

	delete[] headerBuf;
	delete[] buffer_in;
	delete[] buffer_tmp;
	delete[] buffer_out;
	delete[] outframe;

	gAVEngine->loadAsset(strpath);
	gAVEngine->StartPlayBack(0, 0);
}

int 
SerialIO::getSynch(FILE* fd)
{
	int pos = -1;
	bool headerFound = false;
	char tt;

	while (!headerFound)
	{
		fread(&tt, sizeof(char), 1, fd);

		if (tt == 'R')
			headerFound = true;

		pos++;
	}

	return pos;
}

void 
SerialIO::SendCommand(IGOSysCommand data)
{
	mComQueue.Put(data);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
SerialIOThread::ExitCode SerialIOThread::Entry()
{
	gSerialIO->doSerialIO();
	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////


