#ifndef COMMSOENGINE_H
#define COMMMSENGINE_H

#include "wx/wx.h"
#include <vector>

#include "portaudio.h"
#include "pa_ringbuffer.h"
#include "pa_util.h"

#include "..\IGODefs.h"

#include "CommandsQueue.h"
#include "serial.h"

#include <wx/thread.h>
#include <memory>
#include <malloc.h>


#define safenew new

class IGOControllerFrame;
class SerialIO;
class SerialIOThread;

typedef struct SerialPortMap {
	int portIndex;
	wxString address;
	wxString description;
	wxString hardware_id;
	double defaultRate;
} SerialPortMap;


enum eventcode
{
	AVP_PROCESS_FILE_ERROR = -4,
	AVP_PROCESS_CONFIG_ERROR,
	AVP_PROCESS_AUDIO_ERROR,
	AVP_PROCESS_TERM_FAIL,
	AVP_PROCESS_TERM_OK,
	AVP_PROCESS_START,
	AVP_PROCESS_STAGE,
	AVP_PROCESS_RESULT
};

extern SerialIO *gSerialIO;

void InitSerialIO();
void DeinitSerialIO();

class SerialIO
{
    public:
		SerialIO();
        virtual ~SerialIO();

		void SetParent(IGOControllerFrame* parent);

		std::vector<SerialPortMap> GetSerialPorts();

		//opens selected I/O devices
		bool OpenSerialPort(wxString portName, int portSpeed, int frameSize);
		bool CloseSerialPort();

		void StartSerialIO();
		void StopSerialIO();
		int  doSerialIO();

		void SendCommand(IGOSysCommand data);

		std::unique_ptr<SerialIOThread> mSerialThread;


	protected:

		void reportEvent(procid_t processID,
			eventtype_t eventType,
			eventid_t   eventID,
			float value,
			wxString message,
			bool killProcess = false,
			wxString debugInfo = wxEmptyString);

		void decodeUartPktsToAudio();
		int  getSynch(FILE* fd);
		
	protected:

		serial::Serial *mSPortHandle;
		IGOControllerFrame* mParent;
		bool bIsStopped;
		bool mIsSafe;

		std::vector<SerialPortMap> mComPorts;

		wxString mPortName;
		int mPortIndex;
		int mPortRate;
		size_t mFrameLength;

		CommandsQueue mComQueue;
};

#endif // AUDIOENGINE_H
