#ifndef COMMANDSQUEUE_H
#define COMMANDSQUEUE_H

#include <vector>

struct IGOSysCommand {
	uint8_t cmdType;
	uint8_t cmdValue;
};

class CommandsQueue
{
 public:
   CommandsQueue(int maxLen);
   ~CommandsQueue();

   bool Put(IGOSysCommand &msg);
   bool Get(IGOSysCommand &msg);

   void Clear();

 private:
   int             mStart;
   int             mEnd;
   int             mBufferSize;
   IGOSysCommand*     mBuffer;
   IGOSysCommand      mLastValid;
};


#endif // PARAMETERSQUEUE_H
