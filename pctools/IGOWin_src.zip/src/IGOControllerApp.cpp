/***************************************************************
 * Name:      IGOControllerApp.cpp
 * Purpose:   Code for Application Class
 * Author:    clandone ()
 * Created:   2017-09-20
 * Copyright: clandone ()
 * License:
 **************************************************************/

#include "IGOControllerApp.h"

//(*AppHeaders
#include "IGOControllerMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(IGOControllerApp);

bool IGOControllerApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	IGOControllerFrame* Frame = new IGOControllerFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
