// Automatically generated file 
#define PA_USE_WASAPI 1 
#define PA_USE_WMME 1 
#define PA_USE_DS 1 
