/* dummy file to satisfy include without having to patch libsndfile */
